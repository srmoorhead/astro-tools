Included files:

MeanProfile.py -- This is the run file.  Edit the global variables to change IO behavior.
AstroTools.py -- This is the meat of the computing work.  Calculates the profile.
Curve.py -- This is a basic curve object.  Can be used for a variety of things.
DataPoint.py -- This is a basic data point object.  Can be used for a variety of things.
eventPropertiesCorrection.py -- This is a short script to correct the 33e+556 notation and turn it into a float the program can use.  You may or may not need this.

Also included:  Sample data.
